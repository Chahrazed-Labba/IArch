To launch the App, please copy-paste these few lines on your terminal to get in your virtual environnement and then run the App !

1. UPDATE the cd line. Replace the path by your own directory
cd C:\Users\Desktop\IArch_V2

2. ACTIVATE your virtual environnement created during the installation
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.env_IArch\Scripts\Activate.ps1

3. RUN the App
streamlit run app-2.py


